from everywhereml.data.collect.MjpegCollector import MjpegCollector
from everywhereml.data.collect.SerialCollector import SerialCollector
