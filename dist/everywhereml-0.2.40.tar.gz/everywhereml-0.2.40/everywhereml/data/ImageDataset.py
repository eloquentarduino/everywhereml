class ImageDataset:
    """
    Disabled
    """
    pass